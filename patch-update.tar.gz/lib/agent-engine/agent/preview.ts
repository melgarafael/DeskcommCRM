/** Preview is an execution policy of the real turn, never a simulated queue job. */
import type pg from 'pg';
import { hasOpenCaseForContact } from './human-cases';
import type { ToolSet } from '../edge/llm/run-model-call';
import type { LeadContext, LeadContextResult } from '../edge/crm/get-lead-context';
import type { PublishedAgentConfig } from './agent-config';
import type { LeadCheckpointRow } from './inbound-turn';
import { ferramentasDeAgendaDoAgente, temFerramentaDeAgenda } from './inbound-turn';
import {
  BEFORE_SEND_GATES,
  evaluateBeforeSend,
  type Gate,
  type GateContext,
  type GateTraceEntry,
  loadChannelProvider,
  pacingGate,
} from '../guardrails/before-send';
import { loadChannelKnobs, loadPacingState } from '../pacing/store';
import { PACING_DEFAULTS } from '../pacing/defaults';
import { SPINNING_DEFAULTS } from '../spinning/defaults';
import { loadRecentCopies, loadSpinningKnobs } from '../spinning/store';
import { loadPromiseTable } from '../guardrails/promise/table';
import { camadaLigada, lerCamadasDaOrg } from '../guardrails/camadas-da-org';
import { loadDisclosureTemplate, countPriorAcceptedSends } from '../guardrails/disclosure/template';
import { DEFAULT_CHANNEL_PROVIDER } from '@/lib/channels/capabilities';
import { getToolByName } from '@/lib/mcp/tools';
import type { Logger } from '../obs/logger';
import type { Citation } from '@/lib/ai/citations/types';
import type { FotosPreparadas, MidiaPreparada } from './fotos-do-produto';

export interface TurnPreview {
  kind: 'sandbox' | 'assisted';
  organizationId: string;
  runId: string;
  agent: PublishedAgentConfig;
  context: Extract<LeadContextResult, { ok: true }>;
  previous?: LeadCheckpointRow | null;
  notes?: Array<{ headline: string; body: string }>;
  feedback?: string;
  /** Null means a scenario, never a synthetic identifier passed to SQL. */
  contactId: string | null;
  channelId: string | null;
  gateContext?: GateContext;
  result: PreviewResult;
}
export interface PreviewResult {
  checkpoint?: unknown;
  candidates: Array<{ body: string; citations: Citation[]; trace: GateTraceEntry[] }>;
  proposals: Array<{ tool: string; arguments: unknown }>;
  impediments: Array<{ code: string; message: string }>;
  /**
   * O que NÃO impediu o candidato, mas o operador precisa ver sobre o ENVIO real:
   * um gate que o barraria agora, ou uma mídia que não sairia (produto sem fotos,
   * #2490). O aviso de gate só o sandbox escreve (ver `gatesDoSandbox`) — o rascunho
   * assistido trata o mesmo veto como impedimento; o de produto sem fotos
   * (`midia_sem_fotos`) sai nos dois.
   */
  warnings: Array<{ code: string; message: string }>;
  restrictions: string[];
  /**
   * A mídia que a resposta USARIA, preparada pelo MESMO caminho do envio real
   * (#2490): produto resolvido no catálogo, fotos preparadas e anexos previstos.
   * Falha aqui vira `falha` no registro E impedimento no teste — nunca candidato.
   */
  midia: MidiaPreparada[];
}
export function newPreviewResult(): PreviewResult {
  return {
    candidates: [],
    proposals: [],
    impediments: [],
    warnings: [],
    midia: [],
    restrictions: [
      'preview_no_client_effects',
      'writes_require_separate_authorization',
      'send_revalidates_live_state',
    ],
  };
}

export async function previewGateContext(
  db: pg.Pool,
  p: TurnPreview,
  log: Logger,
  now: Date,
): Promise<GateContext> {
  if (p.gateContext) return { ...p.gateContext, now };
  const org = p.organizationId,
    channel = p.channelId;
  const cfg = channel
    ? await loadChannelKnobs(db, org, channel, log)
    : { knobs: PACING_DEFAULTS, numberActivatedAt: null };
  const spinning = channel ? await loadSpinningKnobs(db, org, channel, log) : SPINNING_DEFAULTS;
  const promise = await loadPromiseTable(db, org),
    disclosure = await loadDisclosureTemplate(db, org);
  const first = p.contactId ? (await countPriorAcceptedSends(db, org, p.contactId)) === 0 : true;
  let lastInbound: Date | null = null;
  if (p.contactId && channel) {
    const { rows } = await db.query<{ last_inbound_at: Date | null }>(
      'select last_inbound_at from conversations where organization_id=$1 and id=$2 and contact_id=$3 and channel_session_id=$4',
      [org, p.context.context.conversation_id, p.contactId, channel],
    );
    lastInbound = rows[0]?.last_inbound_at ?? null;
  } else {
    const last = p.context.context.messages.filter((m) => m.direction === 'inbound').at(-1);
    lastInbound = last ? new Date(last.sent_at) : null;
    p.result.restrictions.push('contact_state_is_scenario');
  }
  return {
    now,
    body: '',
    optedOut: p.context.context.contact.is_blocked,
    provider: channel ? await loadChannelProvider(db, org, channel) : DEFAULT_CHANNEL_PROVIDER,
    messagingWindow: { lastInboundAt: lastInbound },
    pacing: {
      knobs: cfg.knobs,
      // A prévia propõe a RESPOSTA a uma mensagem recebida: vale a janela
      // `resposta_*` (0495), a mesma que `approved-reply.ts` usa ao enviar o
      // rascunho aprovado (#1984). Sem isto, o rascunho da prévia seria vetado
      // pelo `outside_window` da janela de DISPARO (7h-22h) em vez da de resposta.
      resposta: true,
      state: channel
        ? await loadPacingState(db, org, channel, {
            now,
            timezone: cfg.knobs.timezone,
            numberActivatedAt: cfg.numberActivatedAt,
          })
        : { lastSentAt: null, sentToday: 0, numberActivatedAt: null },
      crmDailyLimit: null,
    },
    spinning: {
      knobs: spinning,
      window: channel ? await loadRecentCopies(db, org, channel, spinning.windowSize) : [],
    },
    promise: { table: promise?.table ?? null },
    semanticPromise: null,
    disclosure: { template: disclosure?.body ?? null, isFirstOutbound: first, mode: 'inject' },
    lgpd: { ...p.context.lgpd, isFirstOutbound: first },
    casesEnabled: p.agent.casesEnabled,
    hasOpenCase:
      p.contactId && p.agent.casesEnabled
        ? await hasOpenCaseForContact(db, org, p.context.context.conversation_id!)
        : false,
    openedCaseThisTurn: false,
    humanPromiseExtraTargets: p.agent.handoffKeywords,
    // A MESMA condição do turno real (`temFerramentaDeAgenda`): a prévia existe
    // para mostrar o que vai acontecer, e um gate que arma diferente aqui faz
    // quem afina o prompt testar contra outro sistema.
    agenda: {
      active: temFerramentaDeAgenda(p.agent.toolIds),
      ferramentas: ferramentasDeAgendaDoAgente(p.agent.toolIds),
      toolCalledThisTurn: false,
    },
    internalVocabularyEnforced: true,
    // A MESMA decisão do turno real: a camada de afirmação clínica é da organização.
    // Um Testar que arma diferente da produção faz quem afina o prompt testar contra
    // outro sistema — o mesmo motivo do `agenda` logo acima.
    clinicalClaimEnforced: camadaLigada((await lerCamadasDaOrg(db, org)).afirmacao_clinica, false),
  };
}
export const SCENARIO_READS = new Set([
  'crm_list_pipelines',
  'crm_list_stages',
  'crm_list_event_types',
  'crm_find_free_slots',
  'crm_describe_external_data',
  'crm_query_external_data',
  // Catálogo e acervo são material da ORGANIZAÇÃO, não de um contato: sem eles o
  // Testar (que roda sem contato) não responde preço nem agenda e o agente cai
  // em "vou confirmar e te retorno". Dado de contato/lead continua fora daqui.
  'crm_search_products',
  'crm_send_catalog_product',
  'crm_search_knowledge',
]);
/**
 * A cadeia do Testar (sandbox): a de produção, com o veto de pacing rebaixado a aviso.
 *
 * Fora da janela de envio, o `pacingGate` impede que a resposta do modelo
 * apareça como candidato de teste. Janela, aquecimento e limite diário protegem
 * o envio real; o sandbox não envia mensagens. Rebaixar somente esse veto a aviso
 * permite inspecionar o candidato e executar os demais gates de conteúdo.
 *
 * Só o pacing muda, e só aqui. Opt-out, LGPD e os gates de conteúdo continuam vetando;
 * o rascunho assistido (`assisted`, contato real) e a produção seguem com
 * `BEFORE_SEND_GATES` intacta. O veto vira linha `skipped: 'sandbox_send_embargo'` no
 * trace e um aviso explícito no resultado — nunca um `pass` silencioso.
 */
function gatesDoSandbox(avisos: Array<{ code: string; message: string }>): readonly Gate[] {
  return BEFORE_SEND_GATES.map((gate) =>
    gate.name !== pacingGate.name
      ? gate
      : {
          name: gate.name,
          evaluate: (ctx: GateContext) => {
            const verdict = gate.evaluate(ctx);
            if (verdict.pass) return verdict;
            avisos.push({
              code: verdict.code,
              message:
                `Em produção esta resposta não sairia agora (${verdict.reason}). ` +
                'O teste mostra a resposta mesmo assim; nenhuma mensagem foi enviada.',
            });
            return { pass: true, skipped: 'sandbox_send_embargo' as const };
          },
        },
  );
}
/**
 * A MESMA preparação de mídia do envio real, dentro do dry-run (#2490).
 *
 * `preparar` é injetado por quem monta a prévia e resolve a `prepararFotosDoProduto`
 * do caminho de produção — mesma query no catálogo, mesma cópia. Aqui só se
 * traduz o desfecho para o VOCABULÁRIO do teste:
 *
 * - código sem produto, ou foto que não copiou → `falha` (o teste fica VERMELHO;
 *   o envio real degrada para só texto, o teste não pode fingir que passou);
 * - produto sem fotos → conta zerada, sem `falha`: nada a enviar, dito claramente;
 * - sem `preparar` injetado → também `falha`: mídia que ninguém preparou não
 *   pode atravessar o teste como se tivesse sido validada.
 */
async function prepararMidiaNoDryRun(
  preparar: ((codigo: string) => Promise<FotosPreparadas>) | undefined,
  codigo: string,
): Promise<MidiaPreparada> {
  const semProduto = (falha: { code: string; message: string }): MidiaPreparada => ({
    codigo,
    produtoResolvido: false,
    fotosCadastradas: 0,
    fotosPreparadas: 0,
    anexos: [],
    falha,
  });
  if (!preparar)
    return semProduto({
      code: 'midia_nao_preparada',
      message:
        'A mídia desta resposta não foi preparada no teste — não há como afirmar que as fotos ' +
        'saíriam no envio real. Corrija a preparação e execute o teste de novo.',
    });
  const preparadas = await preparar(codigo);
  if (!preparadas.ok) return semProduto({ code: preparadas.code, message: preparadas.message });
  const registro: MidiaPreparada = {
    codigo,
    produtoResolvido: true,
    fotosCadastradas: preparadas.tinha,
    fotosPreparadas: preparadas.fotos.length,
    anexos: [...preparadas.fotos],
  };
  const faltaram = preparadas.tinha - preparadas.fotos.length;
  if (faltaram > 0)
    registro.falha = {
      code: 'midia_nao_preparada',
      message:
        `${faltaram} foto(s) do produto ${JSON.stringify(codigo)} não puderam ser preparadas no ` +
        'teste. Em produção o texto sairia sem elas; aqui o teste falha de propósito, para o ' +
        'problema não chegar só no atendimento real.',
    };
  return registro;
}
/** Unknown tools fail closed. A write proposal never calls its original execute. */
export function applyPreviewPolicy(
  tools: ToolSet,
  p: TurnPreview,
  ctx: GateContext,
  citations: () => Citation[],
  semanticClassifier?: (body: string) => Promise<NonNullable<GateContext['semanticPromise']>>,
  liveContext?: () => Partial<GateContext>,
  /**
   * #2490 — a `prepararFotosDoProduto` do caminho de produção, injetada pelo
   * turno que tem banco e Storage. Sem ela o `produto_codigo` NÃO passa: o
   * teste falha a mídia em vez de aprovar texto com foto pendente.
   */
  prepararMidia?: (codigo: string) => Promise<FotosPreparadas>,
): ToolSet {
  return Object.fromEntries(
    Object.entries(tools).map(([name, definition]) => {
      const nativeRead = [
        'get_lead_context',
        'get_lead_note',
        'search_knowledge',
        'read_skill_reference',
      ].includes(name);
      const catalog = getToolByName(name);
      if (
        nativeRead ||
        (catalog?.category === 'read' && (p.contactId !== null || SCENARIO_READS.has(name)))
      )
        return [name, definition];
      return [
        name,
        {
          ...definition,
          execute: async (args: unknown) => {
            if (name === 'send_message') {
              const body =
                args && typeof args === 'object' && 'body' in args && typeof args.body === 'string'
                  ? args.body
                  : '';
              // #2490 — A MESMA preparação do envio real, e na MESMA ordem: o
              // `produto_codigo` que `crm_search_products` devolveu resolve o
              // produto no catálogo e prepara as fotos ANTES da cadeia (é o que
              // `inbound-turn.ts` faz no caminho de produção). Aqui o preparo é
              // o único efeito — nenhuma mensagem sai pelo canal de entrega e
              // nada é gravado em conversa nenhuma, como `preview_no_client_effects`
              // manda.
              const produtoCodigo =
                args && typeof args === 'object' && 'produto_codigo' in args
                  ? typeof args.produto_codigo === 'string'
                    ? args.produto_codigo
                    : undefined
                  : undefined;
              if (produtoCodigo !== undefined && produtoCodigo.trim() !== '') {
                const midia = await prepararMidiaNoDryRun(prepararMidia, produtoCodigo);
                p.result.midia.push(midia);
                // Falha de mídia NÃO vira candidato: sem degradar para só texto,
                // sem aprovar o teste com a foto pendente (issue #2490, item 6).
                if (midia.falha) {
                  p.result.impediments.push({ code: midia.falha.code, message: midia.falha.message });
                  return {
                    ok: false,
                    error: { code: midia.falha.code, message: midia.falha.message },
                  };
                }
                // Produto sem foto é desfecho LEGÍTIMO do envio real — não é
                // falha, mas o operador tem de ler que nenhuma imagem sairia.
                if (midia.fotosCadastradas === 0 && !p.result.warnings.some((w) => w.code === 'midia_sem_fotos'))
                  p.result.warnings.push({
                    code: 'midia_sem_fotos',
                    message:
                      `O produto ${JSON.stringify(midia.codigo)} não tem fotos cadastradas: ` +
                      'nenhuma imagem seria enviada no envio real — só o texto.',
                  });
              }
              const avisos: Array<{ code: string; message: string }> = [];
              const result = evaluateBeforeSend(
                {
                  ...ctx,
                  ...liveContext?.(),
                  body,
                  semanticPromise: semanticClassifier ? await semanticClassifier(body) : null,
                },
                p.kind === 'sandbox' ? gatesDoSandbox(avisos) : BEFORE_SEND_GATES,
              );
              if (result.veto) {
                p.result.impediments.push({ code: result.veto.code, message: result.veto.message });
                return {
                  ok: false,
                  error: { code: result.veto.code, message: result.veto.message },
                };
              }
              // O aviso acompanha um candidato; vetado por outro gate, o impedimento já diz.
              for (const aviso of avisos)
                if (!p.result.warnings.some((w) => w.code === aviso.code))
                  p.result.warnings.push(aviso);
              p.result.candidates.push({
                body: result.body,
                citations: citations(),
                trace: result.trace,
              });
              return {
                ok: true,
                status: p.kind === 'sandbox' ? 'simulated' : 'awaiting_approval',
                message: 'Resposta proposta. Nenhuma mensagem enviada. Encerre o turno.',
              };
            }
            if (catalog?.category === 'read')
              return {
                ok: false,
                error: {
                  code: 'scenario_contact_unavailable',
                  message: 'Esta consulta precisa de um contato real autorizado.',
                },
              };
            if (
              catalog ||
              [
                'send_template',
                'update_lead_state',
                'save_lead_note',
                'request_human_handoff',
                'schedule_followup',
                'open_human_case',
                'provide_case_update',
              ].includes(name)
            ) {
              p.result.proposals.push({ tool: name, arguments: args });
              return {
                ok: true,
                status: 'proposal_only',
                message:
                  'Proposta registrada. A operação não foi executada e exige autorização separada.',
              };
            }
            p.result.impediments.push({ code: 'unknown_preview_tool', message: name });
            return {
              ok: false,
              error: {
                code: 'unknown_preview_tool',
                message: 'Ferramenta não autorizada no teste.',
              },
            };
          },
        },
      ];
    }),
  ) as ToolSet;
}
export function scenarioContext(
  messages: LeadContext['messages'],
  contact?: { name?: string; phone?: string },
): Extract<LeadContextResult, { ok: true }> {
  return {
    ok: true,
    context: {
      lead_id: '',
      contact: {
        name: contact?.name ?? 'Teste',
        phone: contact?.phone ?? null,
        email: null,
        tags: [],
        is_blocked: false,
      },
      conversation_id: null,
      last_human_decision: null,
      messages,
    },
    tokenCount: 0,
    lgpd: {
      isAnonymized: false,
      isProspecting: false,
      legalBasis: { basis: null, consentGranted: false, legalBasisRef: null, dataOrigin: null },
    },
  };
}
